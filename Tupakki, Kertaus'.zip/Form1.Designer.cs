﻿namespace Tupakki__Kertaus_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            textBox1 = new TextBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            checkBox7 = new CheckBox();
            checkBox8 = new CheckBox();
            checkBox9 = new CheckBox();
            checkBox10 = new CheckBox();
            checkBox11 = new CheckBox();
            checkBox12 = new CheckBox();
            checkBox13 = new CheckBox();
            checkBox14 = new CheckBox();
            label7 = new Label();
            label8 = new Label();
            label10 = new Label();
            checkBox19 = new CheckBox();
            label9 = new Label();
            textBox2 = new TextBox();
            btnLaske = new Button();
            lblTulos = new Label();
            label11 = new Label();
            label12 = new Label();
            btnLaske2 = new Button();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(167, 151);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(187, 29);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Alle 6 minuuttia (3)";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(68, 78);
            label1.Name = "label1";
            label1.Size = new Size(444, 25);
            label1.TabIndex = 1;
            label1.Text = "Kuinka pian herättyäsi poltat ensimmäisen savukkeen? ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(114, 512);
            label2.Name = "label2";
            label2.Size = new Size(338, 25);
            label2.TabIndex = 2;
            label2.Text = "Kuinka monta savuketta poltat päivässä? ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(540, 78);
            label3.Name = "label3";
            label3.Size = new Size(575, 25);
            label3.TabIndex = 3;
            label3.Text = "Onko sinusta vaikeaa olla tupakoimatta tiloissa, joissa se on kiellettyä?  ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(589, 512);
            label4.Name = "label4";
            label4.Size = new Size(437, 25);
            label4.TabIndex = 4;
            label4.Text = "Mistä tupakointikerrasta sinun olisi vaikeinta luopua?  ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(1121, 78);
            label5.Name = "label5";
            label5.Size = new Size(616, 25);
            label5.TabIndex = 5;
            label5.Text = "Poltatko aamun ensimmäisinä tunteina enemmän kuin loppupäivän aikana?  ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(1023, 512);
            label6.Name = "label6";
            label6.Size = new Size(714, 25);
            label6.TabIndex = 6;
            label6.Text = "Tupakoitko, jos olet niin sairas, että joudut olemaan vuoteessa suurimman osan päivää?  ";
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(167, 215);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(180, 29);
            checkBox2.TabIndex = 7;
            checkBox2.Text = "6-30 minuuttia (2)";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(167, 286);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(190, 29);
            checkBox3.TabIndex = 8;
            checkBox3.Text = "31-60 minuuttia (1)";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(167, 353);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(186, 29);
            checkBox4.TabIndex = 9;
            checkBox4.Text = "Yli 60 minuuttia (0)";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(167, 593);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 10;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(167, 744);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(120, 29);
            checkBox5.TabIndex = 11;
            checkBox5.Text = "10 - 19 (1)";
            checkBox5.UseVisualStyleBackColor = true;
            checkBox5.Visible = false;
            checkBox5.CheckedChanged += checkBox5_CheckedChanged;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Location = new Point(167, 818);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(110, 29);
            checkBox6.TabIndex = 12;
            checkBox6.Text = "20-23 (2)";
            checkBox6.UseVisualStyleBackColor = true;
            checkBox6.Visible = false;
            checkBox6.CheckedChanged += checkBox6_CheckedChanged;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Location = new Point(167, 903);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new Size(105, 29);
            checkBox7.TabIndex = 13;
            checkBox7.Text = "yli 24 (3)";
            checkBox7.UseVisualStyleBackColor = true;
            checkBox7.Visible = false;
            checkBox7.CheckedChanged += checkBox7_CheckedChanged;
            // 
            // checkBox8
            // 
            checkBox8.AutoSize = true;
            checkBox8.Location = new Point(720, 241);
            checkBox8.Name = "checkBox8";
            checkBox8.Size = new Size(76, 29);
            checkBox8.TabIndex = 14;
            checkBox8.Text = "Ei (0)";
            checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            checkBox9.AutoSize = true;
            checkBox9.Location = new Point(720, 628);
            checkBox9.Name = "checkBox9";
            checkBox9.Size = new Size(238, 29);
            checkBox9.TabIndex = 15;
            checkBox9.Text = "aamun ensimmäisestä (1)";
            checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            checkBox10.AutoSize = true;
            checkBox10.Location = new Point(720, 703);
            checkBox10.Name = "checkBox10";
            checkBox10.Size = new Size(181, 29);
            checkBox10.TabIndex = 16;
            checkBox10.Text = "Jostain muusta (0)";
            checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            checkBox11.AutoSize = true;
            checkBox11.Location = new Point(1348, 151);
            checkBox11.Name = "checkBox11";
            checkBox11.Size = new Size(98, 29);
            checkBox11.TabIndex = 17;
            checkBox11.Text = "Kyllä (1)";
            checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            checkBox12.AutoSize = true;
            checkBox12.Location = new Point(1348, 241);
            checkBox12.Name = "checkBox12";
            checkBox12.Size = new Size(76, 29);
            checkBox12.TabIndex = 18;
            checkBox12.Text = "Ei (0)";
            checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            checkBox13.AutoSize = true;
            checkBox13.Location = new Point(1348, 628);
            checkBox13.Name = "checkBox13";
            checkBox13.Size = new Size(98, 29);
            checkBox13.TabIndex = 19;
            checkBox13.Text = "Kyllä (1)";
            checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            checkBox14.AutoSize = true;
            checkBox14.Location = new Point(1348, 703);
            checkBox14.Name = "checkBox14";
            checkBox14.Size = new Size(76, 29);
            checkBox14.TabIndex = 20;
            checkBox14.Text = "Ei (0)";
            checkBox14.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(1903, 241);
            label7.Name = "label7";
            label7.Size = new Size(219, 25);
            label7.TabIndex = 21;
            label7.Text = "Yhteispistemäärän tulkinta";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(125, 653);
            label8.Name = "label8";
            label8.Size = new Size(246, 25);
            label8.TabIndex = 26;
            label8.Text = "Jos annoit yli 10 vastaa näihin";
            label8.Visible = false;
            label8.Click += label8_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(114, 703);
            label10.Name = "label10";
            label10.Size = new Size(275, 25);
            label10.TabIndex = 28;
            label10.Text = "montako tupakkaa kysyt askissa?";
            label10.Visible = false;
            label10.Click += label10_Click;
            // 
            // checkBox19
            // 
            checkBox19.AutoSize = true;
            checkBox19.Location = new Point(720, 136);
            checkBox19.Name = "checkBox19";
            checkBox19.Size = new Size(98, 29);
            checkBox19.TabIndex = 29;
            checkBox19.Text = "Kyllä (1)";
            checkBox19.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(425, 703);
            label9.Name = "label9";
            label9.Size = new Size(166, 25);
            label9.TabIndex = 30;
            label9.Text = "Paljonko se maksaa";
            label9.Visible = false;
            label9.Click += label9_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(425, 771);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(150, 31);
            textBox2.TabIndex = 31;
            textBox2.Visible = false;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // btnLaske
            // 
            btnLaske.Location = new Point(1940, 470);
            btnLaske.Name = "btnLaske";
            btnLaske.Size = new Size(112, 34);
            btnLaske.TabIndex = 32;
            btnLaske.Text = "Laske";
            btnLaske.UseVisualStyleBackColor = true;
            btnLaske.Click += btnLaske_Click;
            // 
            // lblTulos
            // 
            lblTulos.AutoSize = true;
            lblTulos.Location = new Point(1754, 357);
            lblTulos.Name = "lblTulos";
            lblTulos.Size = new Size(0, 25);
            lblTulos.TabIndex = 33;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(440, 836);
            label11.Name = "label11";
            label11.Size = new Size(0, 25);
            label11.TabIndex = 34;
            label11.Visible = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(440, 922);
            label12.Name = "label12";
            label12.Size = new Size(0, 25);
            label12.TabIndex = 35;
            label12.Visible = false;
            // 
            // btnLaske2
            // 
            btnLaske2.Location = new Point(643, 769);
            btnLaske2.Name = "btnLaske2";
            btnLaske2.Size = new Size(112, 34);
            btnLaske2.TabIndex = 36;
            btnLaske2.Text = "Laske";
            btnLaske2.UseVisualStyleBackColor = true;
            btnLaske2.Visible = false;
            btnLaske2.Click += btnLaske2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2439, 1114);
            Controls.Add(btnLaske2);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(lblTulos);
            Controls.Add(btnLaske);
            Controls.Add(textBox2);
            Controls.Add(label9);
            Controls.Add(checkBox19);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(checkBox14);
            Controls.Add(checkBox13);
            Controls.Add(checkBox12);
            Controls.Add(checkBox11);
            Controls.Add(checkBox10);
            Controls.Add(checkBox9);
            Controls.Add(checkBox8);
            Controls.Add(checkBox7);
            Controls.Add(checkBox6);
            Controls.Add(checkBox5);
            Controls.Add(textBox1);
            Controls.Add(checkBox4);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(checkBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private TextBox textBox1;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private CheckBox checkBox7;
        private CheckBox checkBox8;
        private CheckBox checkBox9;
        private CheckBox checkBox10;
        private CheckBox checkBox11;
        private CheckBox checkBox12;
        private CheckBox checkBox13;
        private CheckBox checkBox14;
        private Label label7;
        private Label label8;
        private Label label10;
        private CheckBox checkBox19;
        private Label label9;
        private TextBox textBox2;
        private Button btnLaske;
        private Label lblTulos;
        private Label label11;
        private Label label12;
        private Button btnLaske2;
    }
}